import React, { useState } from 'react';
import {
  Stethoscope,
  SkipForward,
  UserX,
  ClockAlert,
  Siren,
  FileText,
  RotateCcw
} from 'lucide-react';

export default function DoctorConsole({
  doctors,
  tokens,
  holdingTokens,
  onCallNext,
  onCompleteCurrent,
  onSetStatus,
  onMarkAbsent,
  onRequeueHolding,
  onEmergencyInject,
  onAttachPrescription
}) {
  const [selectedDocId, setSelectedDocId] = useState(doctors[0]?.id || 'doc-mehta');
  const [customDuration, setCustomDuration] = useState('');
  const [emgName, setEmgName] = useState('');
  const [emgNote, setEmgNote] = useState('Acute chest discomfort — immediate triage');
  const [rxNotes, setRxNotes] = useState('');
  const [rxMeds, setRxMeds] = useState('');
  const [rxTargetTokenId, setRxTargetTokenId] = useState('');

  const doc = doctors.find((d) => d.id === selectedDocId) || doctors[0];
  if (!doc) return null;

  const docTokens = tokens
    .filter((t) => t.doctorId === doc.id && t.status !== 'Completed')
    .sort((a, b) => {
      if (a.priority === 'Emergency' && b.priority !== 'Emergency') return -1;
      if (b.priority === 'Emergency' && a.priority !== 'Emergency') return 1;
      return a.tokenNumber - b.tokenNumber;
    });

  const currentConsulting = docTokens.find((t) => t.status === 'In Consultation');
  const docHolding = holdingTokens.filter((t) => t.doctorId === doc.id);
  const completedOrActiveTokens = tokens.filter((t) => t.doctorId === doc.id);

  const handleEmergencySubmit = (e) => {
    e.preventDefault();
    if (!emgName.trim()) return;
    onEmergencyInject({
      doctorId: doc.id,
      patientName: emgName.trim(),
      triageNote: emgNote.trim() || 'Emergency escalation'
    });
    setEmgName('');
  };

  const handlePrescriptionSubmit = (e) => {
    e.preventDefault();
    const targetId = rxTargetTokenId || currentConsulting?.id || completedOrActiveTokens[0]?.id;
    if (!targetId) return;
    onAttachPrescription(targetId, {
      notes: rxNotes.trim() || 'Continue hydration and monitor symptoms.',
      medications: rxMeds.trim() || 'As discussed in consultation.'
    });
    setRxNotes('');
    setRxMeds('');
  };

  return (
    <section className="space-y-6">
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-100">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-teal-600 text-white flex items-center justify-center">
              <Stethoscope className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-slate-900">Doctor Consultation Control Console</h2>
              <p className="text-sm text-slate-500">
                Advance tokens, log actual consultation duration for EWMA, handle delays & no-shows.
              </p>
            </div>
          </div>

          <select
            value={doc.id}
            onChange={(e) => setSelectedDocId(e.target.value)}
            className="border border-slate-300 rounded-xl px-3.5 py-2 text-sm font-semibold bg-slate-50 focus:outline-none focus:ring-2 focus:ring-teal-500"
          >
            {doctors.map((d) => (
              <option key={d.id} value={d.id}>
                {d.name} ({d.specialty} • Active #{d.activeTokenNumber})
              </option>
            ))}
          </select>
        </div>

        {/* Primary Action Controls */}
        <div className="mt-5 grid grid-cols-1 lg:grid-cols-12 gap-4 items-end">
          <div className="lg:col-span-3">
            <label className="block text-xs font-semibold text-slate-600 mb-1">
              Last Consultation Mins (Optional EWMA)
            </label>
            <input
              type="number"
              min="2"
              max="90"
              placeholder={`EWMA ~${doc.dynamicAvgDuration}m`}
              value={customDuration}
              onChange={(e) => setCustomDuration(e.target.value)}
              className="w-full border border-slate-300 rounded-xl px-3 py-2 text-sm"
            />
          </div>

          <div className="lg:col-span-9 flex flex-wrap gap-2.5">
            <button
              onClick={() => {
                const parsed = customDuration ? Number(customDuration) : undefined;
                onCallNext(doc.id, parsed);
                setCustomDuration('');
              }}
              className="inline-flex items-center gap-2 bg-teal-600 hover:bg-teal-700 text-white font-semibold px-4 py-2.5 rounded-xl text-sm shadow-sm transition"
            >
              <SkipForward className="w-4 h-4" />
              Call Next Patient
            </button>

            <button
              onClick={() => onCompleteCurrent(doc.id)}
              className="inline-flex items-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold px-4 py-2.5 rounded-xl text-sm transition"
            >
              Mark Completed
            </button>

            <button
              onClick={() => onSetStatus(doc.id, { addDelayMins: 10, status: 'Delayed' })}
              className="inline-flex items-center gap-2 bg-amber-100 hover:bg-amber-200 text-amber-900 border border-amber-300 font-semibold px-4 py-2.5 rounded-xl text-sm transition"
            >
              <ClockAlert className="w-4 h-4" />
              Delay +10 mins
            </button>

            <button
              onClick={() =>
                onSetStatus(doc.id, {
                  status: doc.status === 'On Break' ? 'In Consultation' : 'On Break'
                })
              }
              className="inline-flex items-center gap-2 bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-300 font-semibold px-4 py-2.5 rounded-xl text-sm transition"
            >
              {doc.status === 'On Break' ? 'Resume Consultations' : 'Mark On Break'}
            </button>
          </div>
        </div>

        {/* Active Queue Table for Selected Doctor */}
        <div className="mt-6">
          <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider mb-2.5">
            Queue for {doc.name} — Active Token #{doc.activeTokenNumber} (EWMA: {doc.dynamicAvgDuration} min)
          </h3>
          <div className="overflow-x-auto border border-slate-200 rounded-xl">
            <table className="w-full text-left text-sm">
              <thead className="bg-slate-50 text-slate-600 text-xs uppercase border-b border-slate-200">
                <tr>
                  <th className="py-2.5 px-3">Token</th>
                  <th className="py-2.5 px-3">Patient</th>
                  <th className="py-2.5 px-3">Priority</th>
                  <th className="py-2.5 px-3">Status</th>
                  <th className="py-2.5 px-3">Est. Wait</th>
                  <th className="py-2.5 px-3 text-right">No-Show Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {docTokens.map((t) => (
                  <tr key={t.id} className={t.status === 'In Consultation' ? 'bg-teal-50/60' : ''}>
                    <td className="py-2.5 px-3 font-bold text-slate-900">#{t.tokenNumber}</td>
                    <td className="py-2.5 px-3 font-medium text-slate-800">
                      {t.patientName}
                      {t.checkedIn && (
                        <span className="ml-2 text-[11px] bg-emerald-100 text-emerald-700 px-2 py-0.5 rounded-full">
                          Checked-in (&lt;500m)
                        </span>
                      )}
                    </td>
                    <td className="py-2.5 px-3">
                      {t.priority === 'Emergency' ? (
                        <span className="text-xs font-bold bg-rose-100 text-rose-700 px-2 py-0.5 rounded-full">
                          EMERGENCY
                        </span>
                      ) : (
                        <span className="text-xs text-slate-500">Standard</span>
                      )}
                    </td>
                    <td className="py-2.5 px-3 font-semibold text-xs">{t.status}</td>
                    <td className="py-2.5 px-3 text-slate-700">{t.estimatedWaitMins} min</td>
                    <td className="py-2.5 px-3 text-right">
                      <button
                        onClick={() => onMarkAbsent(t.id)}
                        className="inline-flex items-center gap-1 text-xs font-semibold text-rose-700 hover:bg-rose-50 px-2.5 py-1 rounded-lg border border-rose-200"
                      >
                        <UserX className="w-3.5 h-3.5" />
                        Patient Absent - Skip Token
                      </button>
                    </td>
                  </tr>
                ))}
                {docTokens.length === 0 && (
                  <tr>
                    <td colSpan="6" className="py-6 text-center text-slate-500">
                      No active or waiting tokens in queue.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Holding Queue (No-Shows) */}
        {docHolding.length > 0 && (
          <div className="mt-5 bg-amber-50/70 border border-amber-200 rounded-xl p-4">
            <h4 className="text-xs font-bold uppercase tracking-wider text-amber-900 mb-2">
              Holding Queue (Skipped Absent Tokens)
            </h4>
            <div className="flex flex-wrap gap-2">
              {docHolding.map((ht) => (
                <div
                  key={ht.id}
                  className="bg-white border border-amber-300 rounded-lg px-3 py-2 flex items-center gap-3 text-xs"
                >
                  <span className="font-bold">#{ht.tokenNumber} — {ht.patientName}</span>
                  <button
                    onClick={() => onRequeueHolding(ht.id)}
                    className="inline-flex items-center gap-1 text-teal-700 font-semibold hover:underline"
                  >
                    <RotateCcw className="w-3 h-3" />
                    Re-insert
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Stretch Modules: Emergency Escalation & Digital Prescription */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        <form
          onSubmit={handleEmergencySubmit}
          className="bg-white rounded-2xl border border-rose-200 p-5 shadow-sm space-y-3"
        >
          <div className="flex items-center gap-2 text-rose-700 font-bold">
            <Siren className="w-5 h-5" />
            <h3>Emergency Escalation Queue (Triage)</h3>
          </div>
          <p className="text-xs text-slate-500">
            Injects an urgent trauma/critical patient ahead of routine tokens and recalculates wait estimates.
          </p>
          <input
            type="text"
            placeholder="Critical patient full name"
            value={emgName}
            onChange={(e) => setEmgName(e.target.value)}
            className="w-full border border-slate-300 rounded-xl px-3 py-2 text-sm"
            required
          />
          <input
            type="text"
            placeholder="Triage note (e.g., Acute chest pain / trauma)"
            value={emgNote}
            onChange={(e) => setEmgNote(e.target.value)}
            className="w-full border border-slate-300 rounded-xl px-3 py-2 text-sm"
          />
          <button
            type="submit"
            className="w-full bg-rose-600 hover:bg-rose-700 text-white font-semibold py-2.5 rounded-xl text-sm transition"
          >
            Inject Priority Patient Ahead
          </button>
        </form>

        <form
          onSubmit={handlePrescriptionSubmit}
          className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm space-y-3"
        >
          <div className="flex items-center gap-2 text-slate-900 font-bold">
            <FileText className="w-5 h-5 text-teal-600" />
            <h3>Digital Prescription Attachment</h3>
          </div>
          <p className="text-xs text-slate-500">
            Attach visit notes & medications directly to a patient record for instant access in My Appointments.
          </p>
          <select
            value={rxTargetTokenId || currentConsulting?.id || completedOrActiveTokens[0]?.id || ''}
            onChange={(e) => setRxTargetTokenId(e.target.value)}
            className="w-full border border-slate-300 rounded-xl px-3 py-2 text-sm bg-slate-50"
          >
            {completedOrActiveTokens.map((t) => (
              <option key={t.id} value={t.id}>
                Token #{t.tokenNumber} — {t.patientName} ({t.status})
              </option>
            ))}
          </select>
          <input
            type="text"
            placeholder="Medications (e.g., Tab. Atorvastatin 10mg HS x 30d)"
            value={rxMeds}
            onChange={(e) => setRxMeds(e.target.value)}
            className="w-full border border-slate-300 rounded-xl px-3 py-2 text-sm"
          />
          <input
            type="text"
            placeholder="Clinical summary / follow-up instructions"
            value={rxNotes}
            onChange={(e) => setRxNotes(e.target.value)}
            className="w-full border border-slate-300 rounded-xl px-3 py-2 text-sm"
          />
          <button
            type="submit"
            className="w-full bg-slate-900 hover:bg-slate-800 text-white font-semibold py-2.5 rounded-xl text-sm transition"
          >
            Attach Digital Prescription
          </button>
        </form>
      </div>
    </section>
  );
}
