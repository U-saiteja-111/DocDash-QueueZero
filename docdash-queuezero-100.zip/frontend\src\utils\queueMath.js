mkdirexport function computeEwmaDuration(durations = [], fallbackMins = 12) {
  if (!Array.isArray(durations) || durations.length === 0) return fallbackMins;
  const window = durations.slice(-5);
  const alpha = 0.45;
  let ewma = window[0];
  for (let i = 1; i < window.length; i++) {
    ewma = alpha * window[i] + (1 - alpha) * ewma;
  }
  return Math.max(4, Math.min(45, Number(ewma.toFixed(1))));
}

export function computeClientSnapshot(raw) {
  const doctors = (raw.doctors || []).map((doc) => {
    const dynamicAvgDuration = doc.dynamicAvgDuration ?? computeEwmaDuration(doc.recentDurations, doc.baseAvgMins);
    const activeQueue = (raw.tokens || [])
      .filter((t) => t.doctorId === doc.id && t.status !== 'Completed' && t.status !== 'Absent' && t.status !== 'Holding')
      .sort((a, b) => {
        if (a.priority === 'Emergency' && b.priority !== 'Emergency') return -1;
        if (b.priority === 'Emergency' && a.priority !== 'Emergency') return 1;
        return a.tokenNumber - b.tokenNumber;
      });
    const currentObj = activeQueue.find((t) => t.status === 'In Consultation') || activeQueue[0];
    const nextObj = activeQueue.find((t) => t.status === 'Waiting');
    return {
      ...doc,
      dynamicAvgDuration,
      activeTokenNumber: currentObj ? currentObj.tokenNumber : doc.activeTokenNumber,
      nextTokenNumber: nextObj ? nextObj.tokenNumber : null
    };
  });

  const tokens = (raw.tokens || []).map((tok) => {
    const doc = doctors.find((d) => d.id === tok.doctorId);
    if (!doc) return tok;
    const activeQueue = (raw.tokens || [])
      .filter((t) => t.doctorId === doc.id && t.status !== 'Completed' && t.status !== 'Absent' && t.status !== 'Holding')
      .sort((a, b) => {
        if (a.priority === 'Emergency' && b.priority !== 'Emergency') return -1;
        if (b.priority === 'Emergency' && a.priority !== 'Emergency') return 1;
        return a.tokenNumber - b.tokenNumber;
      });
    const idx = activeQueue.findIndex((t) => t.id === tok.id);
    const patientsAhead = idx > 0 ? idx : 0;
    const delayPenalty = doc.status === 'On Break' || doc.status === 'Delayed' ? 10 : 0;
    const estimatedWaitMins =
      tok.status === 'Completed' || tok.status === 'In Consultation'
        ? 0
        : Math.max(0, Math.round(patientsAhead * doc.dynamicAvgDuration + (doc.offsetDelayMins || 0) + delayPenalty));
    return {
      ...tok,
      patientsAhead,
      estimatedWaitMins,
      dynamicAvgDuration: doc.dynamicAvgDuration,
      activeTokenNumber: doc.activeTokenNumber,
      doctorStatus: doc.status,
      shouldAlert: tok.status === 'Waiting' && patientsAhead === 2
    };
  });

  return {
    clinics: raw.clinics || [],
    doctors,
    tokens,
    holdingTokens: raw.holdingTokens || [],
    smsLog: raw.smsLog || []
  };
}
