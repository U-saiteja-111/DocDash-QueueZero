import React, { useState } from 'react';
import { CalendarDays } from 'lucide-react';

const DAYS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
const SLOTS = ['08:30', '10:00', '11:30', '13:00', '17:30', '19:30'];

function heatColor(mins) {
  if (mins <= 18) return 'bg-emerald-100 text-emerald-900 border-emerald-200';
  if (mins <= 32) return 'bg-teal-200/80 text-teal-950 border-teal-300';
  if (mins <= 46) return 'bg-amber-200/90 text-amber-950 border-amber-300';
  return 'bg-rose-200 text-rose-950 border-rose-300';
}

export default function WaitTimeHeatmap({ clinics }) {
  const [clinicId, setClinicId] = useState(clinics[0]?.id || 'clinic-1');
  const clinic = clinics.find((c) => c.id === clinicId) || clinics[0];
  if (!clinic || !clinic.heatmap) return null;

  return (
    <section className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm">
      <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
        <div>
          <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
            <CalendarDays className="w-5 h-5 text-teal-600" />
            Clinic Wait Time Heatmap (Historical Avg Mins)
          </h2>
          <p className="text-xs text-slate-500">
            Spot quieter consultation windows across days of the week before booking.
          </p>
        </div>
        <select
          value={clinic.id}
          onChange={(e) => setClinicId(e.target.value)}
          className="border border-slate-300 rounded-xl px-3 py-1.5 text-sm font-medium bg-slate-50"
        >
          {clinics.map((c) => (
            <option key={c.id} value={c.id}>
              {c.name}
            </option>
          ))}
        </select>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-center text-xs border-collapse">
          <thead>
            <tr>
              <th className="p-2 text-left text-slate-500 font-semibold">Day</th>
              {SLOTS.map((slot) => (
                <th key={slot} className="p-2 text-slate-600 font-semibold">
                  {slot}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {DAYS.map((day) => {
              const row = clinic.heatmap[day] || [25, 25, 25, 25, 25, 25];
              return (
                <tr key={day}>
                  <td className="p-2 text-left font-bold text-slate-800">{day}</td>
                  {row.map((mins, i) => (
                    <td key={SLOTS[i]} className="p-1">
                      <div className={`py-2 px-2 rounded-lg border font-semibold ${heatColor(mins)}`}>
                        {mins}m
                      </div>
                    </td>
                  ))}
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </section>
  );
}
