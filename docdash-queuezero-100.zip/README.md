# DocDash: QueueZero

Real-time multi-clinic appointment token booking and live virtual queue tracking web application built with **React**, **React Router**, **Tailwind CSS**, **Node.js (Express + WebSocket)**, and **EWMA wait-time estimation**.

## Key Capabilities
- **Multi-Clinic Doctor Directory**: Browse 8 doctors across 4 clinics and 4 specialties (*General Medicine*, *Pediatrics*, *Orthopedics*, *Cardiology*).
- **Virtual Token Booking Engine**: Sequential tokens for morning and evening consultation shifts.
- **EWMA & Rolling Queue Estimator**: Computes dynamic wait times using an Exponentially Weighted Moving Average over the last 5 consultations (`alpha = 0.45`) plus delay offsets.
- **Doctor Consultation Control Console**: `Call Next Patient`, `Mark Completed`, `Delay +10 mins`, `On Break` toggle, and `Patient Absent - Skip Token` (holding queue).
- **My Appointments & SMS Simulator**: Live countdown, `<500m` geolocation check-in, digital prescription viewer, and an amber alert + simulated SMS when 2 tokens away.
- **Stretch Features Included**: Emergency Escalation Queue, Geolocation Check-In (`<500m`), Digital Prescription Attachment, and Historical Clinic Wait Time Heatmap.

## Run Locally
1. **Start Backend**:
   ```bash
   cd backend
   npm install
   npm start
   ```
2. **Start Frontend** (in a new terminal):
   ```bash
   cd frontend
   npm install
   npm run dev
   ```
